#!/system/bin/sh


# Log create
rm -rf /data/media/0/Android/DAILY/
mkdir /data/media/0/Android/DAILY
HENLOG=/data/media/0/Android/DAILY/runlogs.txt

check_file() {
  if [[ -f "$1" ]]; then
    return 0
  else
    return 1
  fi
}

read_file_unlock() {
  if check_file "$1"; then
    chmod 444 "$1"
    cat "$1"
  fi
}

write_file_lock() {
  if check_file "$1"; then
    chmod 666 "$1"
    echo "$2" > "$1"
    chmod 444 "$1"
  fi
}
echo -e "[$(date +"%Y-%m-%d %T")] Create Read|Write Function.\n" >> $HENLOG

sleep 20

chmod 664 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "mem" > /sys/power/autosleep
echo "deep" > /sys/power/mem_sleep

echo "Y" > /sys/kernel/debug/dsi-panel-ebbg-fhd-ft8716-video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi-panel-ebbg-fhd-ft8716-video_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_panel_ebbg_fhd_ft8719_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_panel_ebbg_fhd_ft8719_video_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_panel_jdi_fhd_r63452_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_panel_jdi_fhd_r63452_cmd_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_panel_jdi_fhd_nt35596s_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_panel_jdi_fhd_nt35596s_video_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_tianma_fhd_nt36672a_video_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_tianma_fhd_nt36672a_video_display/ulps_enable
echo "Y" > /sys/kernel/debug/dsi_ss_ea8074_notch_fhd_cmd_display/dsi-phy-0_allow_phy_power_off
echo "Y" > /sys/kernel/debug/dsi_ss_ea8074_notch_fhd_cmd_display/ulps_enable
echo -e "[$(date +"%Y-%m-%d %T")] Power Saving | Battery Life \n" >> $HENLOG

nohup daily > /dev/null &

echo -e "[$(date +"%Y-%m-%d %T")] All Done!" >> $HENLOG