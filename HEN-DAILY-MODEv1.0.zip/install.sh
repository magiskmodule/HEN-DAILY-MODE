SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"

ui_print ""
ui_print "
┏━━━┓╋╋╋┏┓╋╋╋╋┏━┓┏━┓╋╋╋╋┏┓
┗┓┏┓┃╋╋╋┃┃╋╋╋╋┃┃┗┛┃┃╋╋╋╋┃┃
╋┃┃┃┣━━┳┫┃┏┓╋┏┫┏┓┏┓┣━━┳━┛┣━━┓
╋┃┃┃┃┏┓┣┫┃┃┃╋┃┃┃┃┃┃┃┏┓┃┏┓┃┃━┫
┏┛┗┛┃┏┓┃┃┗┫┗━┛┃┃┃┃┃┃┗┛┃┗┛┃┃━┫
┗━━━┻┛┗┻┻━┻━┓┏┻┛┗┛┗┻━━┻━━┻━━┛
╋╋╋╋╋╋╋╋╋╋┏━┛┃
╋╋╋╋╋╋╋╋╋╋┗━━┛"
ui_print " HENVX DAILY  " 
ui_print " VERSION : 1.0 Beta "
ui_print ""
ui_print " Installing Down. "
ui_print ""
ui_print ""
ui_print " Done "